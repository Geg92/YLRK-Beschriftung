import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, ThinkingLevel } from "@google/genai";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Use JSON middleware with expanded capacity for base64 images
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  // Initialize Gemini Client
  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });

  // API Routes
  app.post("/api/chat", async (req, res) => {
    try {
      const { messages, language } = req.body;
      const isEn = language === "en";
      
      const systemInstruction = isEn 
        ? `You are a helpful AI assistant for YLRK Lettering (YLRK Beschriftungen), a premium sign-making and vehicle wrapping company in Switzerland.
You answer questions about vehicle lettering, car wrapping, shop window wrapping, building signs, and textile printing.
Be professional, friendly, and helpful. Always reply clearly in English.
Approximate standard pricing is as follows (mentioned in the CostCalculator):
- Vehicle Lettering: from CHF 350
- Car Wrapping (Vollfolierung): from CHF 2500
- Shop Window Lettering: from CHF 150
- Company Signs: from CHF 180
- Textile Printing: from CHF 25 per piece

Do not hesitate to recommend that the client request a personalized quote using the local inquiry form on the main page, or via Phone/WhatsApp (+41 76 433 77 95).`
        : `Du bist ein hilfreicher KI-Assistent für YLRK Beschriftungen, ein erstklassiges Unternehmen für Werbetechnik in der Schweiz. 
Du beantwortest Fragen zu Fahrzeugbeschriftungen, Schaufensterbeklebung, Gebäudebeschriftung und Textildruck. 
Sei professionell, freundlich und hilfsbereit. Gib klare und präzise Antworten auf Deutsch.
Die Richtpreise sind wie folgt (im CostCalculator erwähnt):
- Fahrzeugbeschriftung: ab CHF 350
- Vollfolierung (Car Wrapping): ab CHF 2500
- Schaufensterbeschriftung: ab CHF 150
- Firmenschilder: ab CHF 180
- Textildruck: ab CHF 25 per Stück

Zögere nicht, dem Kunden zu empfehlen, über das Kontaktformular auf der Hauptseite oder per Telefon/WhatsApp eine individuelle Offerte einzuholen.`;

      const lastMessage = messages[messages.length - 1].content;
      
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: lastMessage,
        config: {
          systemInstruction: systemInstruction,
        }
      });

      res.json({ text: response.text });
    } catch (error) {
      console.error("Gemini API error:", error);
      res.status(500).json({ error: "Fehler bei der KI-Anfrage" });
    }
  });

  // 1. Image Generation & Editing API (Control aspect ratios, Create / Edit Images)
  app.post("/api/generate-image", async (req, res) => {
    try {
      const { prompt, aspectRatio, mode, image, mimeType } = req.body;
      
      // Select model based on user's selected mode (General vs. Studio Quality)
      const selectedModel = mode === "studio" 
        ? "gemini-3-pro-image" 
        : "gemini-3.1-flash-image";

      // Map aspect ratios to supported SDK configurations (closest match)
      // Supported: "1:1", "3:4", "4:3", "9:16", "16:9". "gemini-3.1-flash-image" supports "1:4" etc.
      let sdkAspectRatio = '1:1';
      if (aspectRatio === '16:9' || aspectRatio === '21:9') sdkAspectRatio = '16:9';
      else if (aspectRatio === '9:16') sdkAspectRatio = '9:16';
      else if (aspectRatio === '2:3' || aspectRatio === '3:4') sdkAspectRatio = '3:4';
      else if (aspectRatio === '3:2' || aspectRatio === '4:3') sdkAspectRatio = '4:3';

      let response;

      if (image) {
        // Image Editing: prompt with base64 reference image + text instructions
        response = await ai.models.generateContent({
          model: selectedModel,
          contents: [
            {
              inlineData: {
                data: image.split(",")[1] || image, // remove mime header if present
                mimeType: mimeType || "image/png"
              }
            },
            { text: `Edit this image based on the following instruction: ${prompt}. Place lettering or print decals realistically and output the final updated photographic image.` }
          ]
        });
      } else {
        // Regular generation from scratch
        response = await ai.models.generateContent({
          model: selectedModel,
          contents: prompt,
          config: {
            imageConfig: {
              aspectRatio: sdkAspectRatio as any,
              imageSize: "1K"
            }
          }
        });
      }

      // Iterate over parts to retrieve base64 image data
      let base64Output = null;
      let textOutput = "";
      
      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData?.data) {
            base64Output = part.inlineData.data;
          } else if (part.text) {
            textOutput += part.text;
          }
        }
      }

      if (base64Output) {
        res.json({ imageUrl: `data:image/png;base64,${base64Output}` });
      } else {
        res.status(400).json({ error: "Kein Bild generiert.", details: textOutput });
      }
    } catch (error: any) {
      console.error("Image generation error:", error);
      let message = "Fehler bei der Bildgenerierung.";
      let details = error.message || "";
      if (details.includes("RESOURCE_EXHAUSTED") || details.includes("quota") || details.includes("429") || details.includes("limit")) {
        message = "Gemini API-Limit / quota erreicht (Kostenlose AI-Studio-Schlüssel besitzen kein Image-Quota).";
        details = "Um professionelle Designs live zu generieren, fügen Sie bitte in Ihren Google AI Studio Einstellungen eine Abrechnungsmethode hinzu (Pay-As-You-Go). Alternativ können Sie Ihre eigenen Referenzen über die Funktion 'Referenzfotos austauschen' einspielen.";
      }
      res.status(500).json({ error: message, details: details });
    }
  });

  // 2. Veo Video Generation API (Animate Images Into Video)
  app.post("/api/generate-video", async (req, res) => {
    try {
      const { prompt, image, mimeType, aspectRatio } = req.body;

      // veo-3.1-lite-generate-preview
      const modelName = 'veo-3.1-lite-generate-preview';
      const sdkAspectRatio = aspectRatio === '9:16' ? '9:16' : '16:9'; // Portrait or landscape only

      let operation = await ai.models.generateVideos({
        model: modelName,
        prompt: prompt || 'Generate high fidelity cinematic camera panning animation overlaying dynamic 3D lighting',
        image: image ? {
          imageBytes: image.split(",")[1] || image,
          mimeType: mimeType || 'image/png'
        } : undefined,
        config: {
          numberOfVideos: 1,
          resolution: '720p',
          aspectRatio: sdkAspectRatio
        }
      });

      res.json({ operationName: operation.name });
    } catch (error: any) {
      console.error("Video operation initial failure:", error);
      let message = "Fehler beim Starten der Videogenerierung.";
      let details = error.message || "";
      if (details.includes("RESOURCE_EXHAUSTED") || details.includes("quota") || details.includes("429") || details.includes("limit")) {
        message = "Gemini Videolimit / quota erreicht (Kostenlose AI-Studio-Schlüssel besitzen kein Video-Quota).";
        details = "Um faszinierende Folierungsvideos zu rendern, fügen Sie bitte in Ihren Google AI Studio Einstellungen eine Abrechnungsmethode hinzu (Pay-As-You-Go).";
      }
      res.status(500).json({ error: message, details: details });
    }
  });

  // Veo Polling Status API
  app.post("/api/video-status", async (req, res) => {
    try {
      const { operationName } = req.body;
      const op: any = { name: operationName };
      
      const updated = await ai.operations.getVideosOperation({ operation: op });
      res.json({ done: updated.done });
    } catch (error: any) {
      console.error("Video status check error:", error);
      res.status(500).json({ error: "Fehler beim Abfragen des Videostatus.", details: error.message });
    }
  });

  // Veo Binary Download Stream Proxy (Hides API Key and handles iframe constraints)
  app.get("/api/video-download", async (req, res) => {
    try {
      const operationName = req.query.operationName as string;
      if (!operationName) {
        return res.status(400).json({ error: "fehlender operationName Parameter" });
      }

      const op: any = { name: operationName };
      const updated = await ai.operations.getVideosOperation({ operation: op });
      
      if (!updated.done) {
        return res.status(202).json({ error: "Video wird noch generiert." });
      }

      const uri = updated.response?.generatedVideos?.[0]?.video?.uri;
      if (!uri) {
        return res.status(404).json({ error: "Video-URI nicht gefunden." });
      }

      // Fetch the binary file with Gemini key authorization
      const key = process.env.GEMINI_API_KEY;
      const videoRes = await globalThis.fetch(uri, {
        headers: { 'x-goog-api-key': key || "" },
      });

      if (!videoRes.ok) {
        return res.status(videoRes.status).send("Fehler beim Abrufen der Video-Ressource.");
      }

      const buffer = Buffer.from(await videoRes.arrayBuffer());
      res.setHeader('Content-Type', 'video/mp4');
      res.setHeader('Content-Disposition', 'attachment; filename="ylrk-video.mp4"');
      res.send(buffer);
    } catch (error: any) {
      console.error("Video download stream error:", error);
      res.status(500).json({ error: "Video Download fehlgeschlagen.", details: error.message });
    }
  });

  // 3. Complex Consulting Advisor API (Hohe Denkstufe)
  app.post("/api/chat-advanced", async (req, res) => {
    try {
      const { prompt, useHighThinking } = req.body;

      let response;
      
      if (useHighThinking) {
        // High Thinking triggers gemini-3.1-pro-preview with HIGH thinking level (no maxOutputTokens)
        response = await ai.models.generateContent({
          model: "gemini-3.1-pro-preview",
          contents: prompt,
          config: {
            systemInstruction: "Du bist ein erstklassiger Schweizer Werbetechnik-Experte und Designberater. Nutze dein profundes Fachwissen, um hochkomplexe und strategisch durchdachte Beratung zur Fahrzeug- und Schaufensterbeschriftung bereitzustellen.",
            thinkingConfig: {
              thinkingLevel: ThinkingLevel.HIGH
            }
          }
        });
      } else {
        // Fallback simple query
        response = await ai.models.generateContent({
          model: "gemini-3.5-flash",
          contents: prompt
        });
      }

      res.json({ text: response.text });
    } catch (error: any) {
      console.error("Advanced query error:", error);
      res.status(500).json({ error: "Fehler beim Verarbeiten der Anfrage.", details: error.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
