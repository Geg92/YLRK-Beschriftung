import { motion } from 'motion/react';
import { ArrowRight, Star, Play, Pause, Upload, Trash2, Film } from 'lucide-react';
import { TypewriterText } from './TypewriterText';
import React, { useState, useEffect, useRef } from 'react';
import { getStoredHeroVideo, saveStoredHeroVideo, deleteStoredHeroVideo } from '../lib/mediaDb';
import { useLanguage } from '../lib/LanguageContext';

export function Hero() {
  const { t, language } = useLanguage();
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const scrollToContact = () => {
    document.getElementById('offerte')?.scrollIntoView({ behavior: 'smooth' });
  };

  // Load video from IndexedDB on mount
  useEffect(() => {
    async function loadVideo() {
      const blob = await getStoredHeroVideo();
      if (blob) {
        const url = URL.createObjectURL(blob);
        setVideoUrl(url);
      }
    }
    loadVideo();

    return () => {
      if (videoUrl) {
        URL.revokeObjectURL(videoUrl);
      }
    };
  }, []);

  const handleFile = async (file: File) => {
    if (!file.type.startsWith('video/')) {
      alert(language === 'en' ? 'Please select a valid video file.' : 'Bitte wählen Sie eine gültige Videodatei aus.');
      return;
    }
    
    // Save to database
    const success = await saveStoredHeroVideo(file);
    if (success) {
      if (videoUrl) {
        URL.revokeObjectURL(videoUrl);
      }
      const url = URL.createObjectURL(file);
      setVideoUrl(url);
      setIsPlaying(true);
    } else {
      alert(language === 'en' ? 'Error saving video to browser storage.' : 'Fehler beim Speichern des Videos im Browser-Speicher.');
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const handleRemoveVideo = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm(language === 'en' ? 'Do you want to remove the uploaded video and restore the project placeholder?' : 'Möchten Sie das hochgeladene Video entfernen und den Projektplatzhalter wiederherstellen?')) {
      const success = await deleteStoredHeroVideo();
      if (success) {
        if (videoUrl) {
          URL.revokeObjectURL(videoUrl);
        }
        setVideoUrl(null);
      }
    }
  };

  const togglePlay = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
        setIsPlaying(false);
      } else {
        videoRef.current.play().catch(() => {});
        setIsPlaying(true);
      }
    }
  };

  return (
    <section id="home" className="relative min-h-[90vh] flex items-center pt-20 overflow-hidden">
      {/* Background Graphic - abstract plotter effect */}
      <div className="absolute inset-0 z-0 opacity-20 pointer-events-none overflow-hidden flex items-center justify-end">
        <motion.div
           initial={{ opacity: 0, scale: 0.8 }}
           animate={{ opacity: 1, scale: 1 }}
           transition={{ duration: 1.5, ease: "easeOut" }}
           className="w-[800px] h-[800px] border-[1px] border-brand-cyan rounded-full absolute -right-40 -top-20"
        />
        <motion.div
           initial={{ opacity: 0, scale: 0.8 }}
           animate={{ opacity: 1, scale: 1 }}
           transition={{ duration: 1.5, delay: 0.2, ease: "easeOut" }}
           className="w-[600px] h-[600px] border-[1px] border-brand-cyan rounded-full absolute -right-20 -top-10"
        />
        {/* Plotter line animation */}
        <motion.svg
          className="absolute right-0 top-1/2 -translate-y-1/2 w-1/2 h-full opacity-30"
          viewBox="0 0 400 800"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <motion.path
            d="M 400 0 C 100 200, 300 600, 0 800"
            stroke="#111111"
            strokeWidth="2"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 3, ease: "easeInOut", repeat: Infinity, repeatType: "reverse" }}
          />
        </motion.svg>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full grid lg:grid-cols-2 gap-12 items-center">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-2xl"
        >
          {/* Trust badge */}
          <div className="inline-flex items-center space-x-2 bg-brand-surface border border-black/10 px-3 py-1.5 rounded-full mb-8">
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-brand-cyan text-brand-cyan" />
              ))}
            </div>
            <span className="text-xs font-medium text-brand-muted">
              {t('hero.trustBadge')}
            </span>
          </div>

          <h1 className="text-6xl sm:text-7xl lg:text-8xl font-display font-bold leading-[0.9] tracking-tight mb-6 uppercase">
            {t('hero.headingLine1')}<br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-cyan to-blue-500">
              {t('hero.headingLine2')}
            </span><br />
            {t('hero.headingLine3')}
          </h1>
          
          <div className="text-lg sm:text-xl text-brand-muted mb-8 max-w-lg leading-relaxed h-[60px] sm:h-[84px]">
            {t('hero.professionell')}
            <TypewriterText 
              words={language === 'en' 
                ? ['Vehicle Wrapping', 'Signage Tech', 'Textile Print', 'Window Lettering'] 
                : ['Fahrzeugbeschriftung', 'Werbetechnik', 'Textildruck', 'Schaufensterbeschriftung']
              } 
            />
            <br />
            {t('hero.serviceSubtitle')}
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <button 
              onClick={scrollToContact}
              className="bg-brand-cyan text-white px-8 py-4 rounded text-lg font-bold hover:opacity-80 transition-colors flex items-center justify-center uppercase tracking-wide group"
            >
              {t('nav.offerte')}
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <a 
              href="#leistungen"
              className="px-8 py-4 rounded text-lg font-bold border border-black/20 hover:bg-black/5 transition-colors flex items-center justify-center uppercase tracking-wide"
            >
              {t('hero.services')}
            </a>
          </div>
        </motion.div>

        {/* Hero Asset Container (Interactive Video Player & Uploader) */}
        <motion.div
           initial={{ opacity: 0, x: 20 }}
           animate={{ opacity: 1, x: 0 }}
           transition={{ duration: 0.8, delay: 0.2 }}
           id="hero-video-showcase"
           className={`relative h-[450px] lg:h-[580px] rounded-2xl overflow-hidden border transition-all duration-300 hidden md:block group cursor-pointer ${
             isDragging 
               ? 'border-brand-cyan bg-brand-cyan/10 scale-[1.01] shadow-[0_12px_40px_rgba(23,162,184,0.15)]' 
               : 'border-black/10 bg-brand-surface shadow-lg hover:border-black/20'
           }`}
           onClick={videoUrl ? togglePlay : triggerFileInput}
           onDragOver={handleDragOver}
           onDragLeave={handleDragLeave}
           onDrop={handleDrop}
        >
          {/* File input for manual selection */}
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileChange} 
            accept="video/*" 
            className="hidden" 
          />

          {videoUrl ? (
            // Full Video Player Mode
            <div className="absolute inset-0 w-full h-full bg-black">
              <video
                ref={videoRef}
                src={videoUrl}
                loop
                muted
                playsInline
                autoPlay
                className="w-full h-full object-cover"
              />
              
              {/* Modern Video Overlay UI */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/30 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-between p-6">
                
                {/* Top Bar controls */}
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2 bg-black/50 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10">
                    <span className="w-2.5 h-2.5 rounded-full bg-brand-cyan animate-pulse" />
                    <span className="text-[11px] font-mono text-white tracking-wider uppercase">{t('hero.preview')}</span>
                  </div>
                  
                  <button
                    onClick={handleRemoveVideo}
                    className="p-2 rounded-full bg-red-500/80 hover:bg-red-600 text-white transition-colors duration-200 shadow-md transform hover:scale-105"
                    title={language === 'en' ? 'Remove Video' : 'Video entfernen'}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                {/* Bottom Bar Controls & Play indicator */}
                <div className="flex items-end justify-between">
                  <div className="flex flex-col text-white max-w-xs md:max-w-md">
                    <p className="text-sm font-bold tracking-tight uppercase mb-1">{t('hero.customAction')}</p>
                    <p className="text-xs text-white/70 font-sans leading-snug">
                      {t('hero.customDesc')}
                    </p>
                  </div>
                  
                  <div className="w-12 h-12 rounded-full bg-brand-cyan/95 text-white flex items-center justify-center shadow-lg border border-white/10 hover:bg-brand-cyan transition-colors transform hover:scale-105">
                    {isPlaying ? (
                      <Pause className="w-5 h-5 fill-current" />
                    ) : (
                      <Play className="w-5 h-5 fill-current translate-x-0.5" />
                    )}
                  </div>
                </div>

              </div>
              
              {/* Play state indicator overlay when paused */}
              {!isPlaying && (
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center transition-all duration-300">
                  <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-md border border-white/30 text-white flex items-center justify-center">
                    <Play className="w-8 h-8 fill-current translate-x-1" />
                  </div>
                </div>
              )}
            </div>
          ) : (
            // Custom high-end interactive mock representation of the Tesla wrap video
            <div className="absolute inset-0 w-full h-full flex flex-col justify-between p-8 bg-gradient-to-br from-[#121214] via-[#1E1F22] to-[#2B2D31] text-white">
              
              {/* Header Info */}
              <div className="flex justify-between items-start">
                <div className="space-y-1">
                  <div className="inline-flex items-center gap-1.5 bg-brand-cyan/10 border border-brand-cyan/20 px-2.5 py-1 rounded-full">
                    <Film className="w-3.5 h-3.5 text-brand-cyan" />
                    <span className="text-[10px] font-mono text-brand-cyan tracking-wider font-bold uppercase">{t('hero.workInProgress')}</span>
                  </div>
                  <h3 className="text-xl font-display font-medium tracking-tight mt-2 text-white">
                    {t('hero.teslaWrap')}
                  </h3>
                </div>
                <div className="text-right font-mono text-xs text-gray-400">
                  <span>YLRK REINACH</span>
                </div>
              </div>

              {/* Central Visual / Animation Wrapper */}
              <div className="my-auto flex flex-col items-center justify-center text-center py-6">
                
                {/* Pulsing Target Ring */}
                <div className="relative mb-6">
                  <div className="absolute inset-0 rounded-full bg-brand-cyan/20 animate-ping opacity-60" style={{ animationDuration: '3s' }} />
                  <div className="relative w-20 h-20 rounded-full bg-gradient-to-tr from-brand-cyan to-blue-600 flex items-center justify-center shadow-lg border border-white/10 group-hover:scale-105 transition-transform duration-300">
                    <Upload className="w-8 h-8 text-white animate-bounce" style={{ animationDuration: '2s' }} />
                  </div>
                </div>

                <p className="text-lg font-bold tracking-tight mb-2 uppercase">
                  {isDragging 
                    ? (language === 'en' ? 'Release video here!' : 'Video hier loslassen!') 
                    : t('hero.dropTitle')
                  }
                </p>
                <p className="text-xs text-gray-400 max-w-sm mx-auto leading-relaxed">
                  {t('hero.dropDesc')}
                </p>
              </div>

              {/* Footer specs / callout */}
              <div className="bg-white/5 rounded-xl border border-white/5 p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-black/40 flex items-center justify-center font-mono text-xs font-bold text-brand-cyan">
                    MP4
                  </div>
                  <div className="text-left">
                    <p className="text-xs font-bold uppercase text-white tracking-wider">{t('hero.dropFooterTitle')}</p>
                    <p className="text-[10px] text-gray-400">{t('hero.dropFooterDesc')}</p>
                  </div>
                </div>
                
                <span className="text-xs font-semibold text-brand-cyan hover:underline flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                  {t('hero.dropFooterBtn')}
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>

            </div>
          )}
        </motion.div>
      </div>
    </section>
  );
}

