import { motion, AnimatePresence } from 'motion/react';
import React, { useState, useEffect } from 'react';
import { Heart, Play, ExternalLink, ShieldCheck, Bookmark, Sparkles, Camera, Trash2, X, ZoomIn } from 'lucide-react';
import { useLanguage } from '../lib/LanguageContext';
import { getStoredHeroVideo, getStoredInstagramImage, saveStoredInstagramImage, deleteStoredInstagramImage } from '../lib/mediaDb';

const InstagramIcon = ({ className, size = 24 }: { className?: string, size?: number }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
    <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
  </svg>
);

interface FeedPost {
  id: string;
  type: 'image' | 'video';
  userVideo?: boolean;
  title: string;
  caption: string;
  likes: number;
  comments: number;
  location: string;
  date: string;
  renderVisual: () => React.ReactNode;
}

export function InstagramPromo() {
  const { language, t } = useLanguage();
  const isEn = language === 'en';
  const [zoomedPost, setZoomedPost] = useState<FeedPost | null>(null);
  const [localVideoUrl, setLocalVideoUrl] = useState<string | null>(null);
  const [customMedias, setCustomMedias] = useState<Record<string, { url: string; isVideo: boolean }>>({});
  const [uploadTargetId, setUploadTargetId] = useState<string | null>(null);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  useEffect(() => {
    async function checkLocalVideo() {
      const blob = await getStoredHeroVideo();
      if (blob) {
        const url = URL.createObjectURL(blob);
        setLocalVideoUrl(url);
      }
    }
    checkLocalVideo();
    return () => {
      if (localVideoUrl) {
        URL.revokeObjectURL(localVideoUrl);
      }
    };
  }, []);

  useEffect(() => {
    async function loadCustomMedias() {
      const postIds = ['tesla-wrap', 'hagex-fleet', 'h-therm-window', 'plotter-precision'];
      const loaded: Record<string, { url: string; isVideo: boolean }> = {};
      
      for (const id of postIds) {
        const blob = await getStoredInstagramImage(id);
        if (blob) {
          loaded[id] = {
            url: URL.createObjectURL(blob),
            isVideo: blob.type.startsWith('video/')
          };
        }
      }
      setCustomMedias(loaded);
    }
    loadCustomMedias();

    return () => {
      Object.values(customMedias).forEach((m: any) => {
        if (m && m.url) {
          URL.revokeObjectURL(m.url);
        }
      });
    };
  }, []);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!uploadTargetId || !e.target.files || !e.target.files[0]) return;
    const file = e.target.files[0];
    const isVideo = file.type.startsWith('video/');
    
    const success = await saveStoredInstagramImage(uploadTargetId, file);
    if (success) {
      if (customMedias[uploadTargetId]) {
        URL.revokeObjectURL(customMedias[uploadTargetId].url);
      }
      const url = URL.createObjectURL(file);
      setCustomMedias(prev => ({
        ...prev,
        [uploadTargetId]: { url, isVideo }
      }));
    } else {
      alert('Fehler beim Speichern der Datei.');
    }
    setUploadTargetId(null);
    if (e.target) {
      e.target.value = '';
    }
  };

  const feedPostsRaw: FeedPost[] = [
    {
      id: 'tesla-wrap',
      type: 'video',
      userVideo: true,
      title: 'Tesla Model Y Wrapping',
      caption: '🔥 TESLA MODEL Y VOLLFOLIERUNG! Sportliche Teilfolierung mit mattweissen ip3 Decals, Konturschnitten auf satiniertem Schwarz für ip3 architektur. Perfekt ausgeführt unter unserer modernen LED-Wabenbeleuchtung. #carwrap #tesla #ylrk #folierung #reinach #carwrapping #ip3',
      likes: 184,
      comments: 32,
      location: 'YLRK Atelier, Reinach BL',
      date: 'Vor 2 Tagen',
      renderVisual: () => (
        <div className="absolute inset-0 bg-neutral-900 flex flex-col justify-between overflow-hidden">
          {localVideoUrl ? (
            <video 
              src={localVideoUrl} 
              autoPlay 
              muted 
              loop 
              playsInline 
              className="absolute inset-0 w-full h-full object-cover"
            />
          ) : (
            <>
              {/* Complex CSS illustration resembling the real video */}
              <div className="absolute inset-0 bg-gradient-to-b from-[#111] via-[#1a1c1e] to-black" />
              {/* Honeycomb ceiling grid representation */}
              <div className="absolute top-0 inset-x-0 h-1/3 opacity-30 flex items-center justify-center pointer-events-none">
                <div className="grid grid-cols-4 gap-1 transform rotate-12 scale-125">
                  {[...Array(12)].map((_, i) => (
                    <div key={i} className="w-10 h-10 border border-brand-cyan rounded-md opacity-60 flex items-center justify-center text-[8px] font-mono" />
                  ))}
                </div>
              </div>
              {/* Car Body representation */}
              <div className="absolute inset-x-4 bottom-8 top-12 flex flex-col items-center justify-center">
                <div className="relative w-40 h-20 bg-neutral-950 rounded-2xl border border-neutral-800 shadow-[0_10px_35px_rgba(0,0,0,0.8)] flex items-center justify-center overflow-hidden">
                  <div className="absolute left-[-20px] w-12 h-12 bg-red-600/30 blur-xl rounded-full" />
                  {/* Wheel lines */}
                  <div className="absolute bottom-1 left-4 w-7 h-7 rounded-full bg-neutral-900 border border-neutral-700 flex items-center justify-center text-[6px]">CD</div>
                  <div className="absolute bottom-1 right-4 w-7 h-7 rounded-full bg-neutral-900 border border-neutral-700 flex items-center justify-center text-[6px]">CD</div>
                  
                  {/* The exact decals shown in the video: "ip3" and "813" */}
                  <div className="text-center text-white z-10 px-2 py-1">
                    <div className="text-[20px] font-black font-display tracking-tighter text-white select-none">ip3</div>
                    <div className="text-[7px] text-gray-400 font-mono tracking-wide uppercase">baumanagement</div>
                  </div>
                </div>
                {/* Wrap specialist tool line */}
                <div className="absolute bottom-5 right-20 w-8 h-1 bg-brand-cyan animate-pulse rounded-full" />
              </div>
            </>
          )}
          {/* Badge & Caption overlays */}
          <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/10 flex items-center gap-1.5 z-10">
            <span className="w-1.5 h-1.5 rounded-full bg-brand-cyan animate-pulse" />
            <span className="text-[9px] font-mono text-white tracking-widest uppercase">{isEn ? 'VIDEO' : 'VIDEO'}</span>
          </div>
          <div className="absolute bottom-3 left-3 bg-brand-cyan/95 text-white text-[10px] py-1 px-2.5 rounded font-bold uppercase tracking-wider z-10 flex items-center gap-1">
            <Play className="w-3 h-3 fill-current" />
            {localVideoUrl ? (isEn ? 'Your video is playing' : 'Ihr Video spielt ab') : (isEn ? 'Live Wrapping' : 'Live Wrapping')}
          </div>
        </div>
      )
    },
    {
      id: 'hagex-fleet',
      type: 'image',
      title: 'HAGEX Flottenbeschriftung',
      caption: '🚀 Und das nächste Flottenfahrzeug für HAGEX HAUSHALTSGERÄTE ist bereit für die Schweizer Strassen! Strahlend weisses Branding auf Tiefschwarz mit langlebiger Premium-Folie für maximale Visibility. #hagex #ylrk #beschriftung #flotte #fleetbranding #reinach',
      likes: 142,
      comments: 18,
      location: 'Kanton Baselland, Schweiz',
      date: 'Vor 4 Tagen',
      renderVisual: () => (
        <div className="absolute inset-0 bg-neutral-900 flex flex-col justify-between overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-tr from-stone-900 to-neutral-800" />
          {/* Vector representation of HAGEX vehicle */}
          <div className="absolute inset-0 flex flex-col items-center justify-center p-4">
            <div className="relative w-44 h-24 bg-neutral-950 rounded-xl border border-neutral-800 shadow-2xl flex flex-col justify-between p-3 overflow-hidden">
              <div className="flex justify-between items-start">
                <span className="text-[12px] font-black tracking-tight text-white font-sans uppercase">HAGEX</span>
                <span className="text-[5px] text-gray-400 font-mono">Service-Mobil</span>
              </div>
              <div className="text-[7px] text-brand-cyan font-bold leading-normal">
                HAUSHALTSGERÄTE<br />
                <span className="text-white text-[6px] font-light">Verkauf & Reparaturen</span>
              </div>
              <div className="absolute bottom-2 right-2 flex gap-1">
                <div className="w-4 h-4 rounded-full border border-neutral-800 bg-neutral-900 flex items-center justify-center text-[5px]">W</div>
                <div className="w-4 h-4 rounded-full border border-neutral-800 bg-neutral-900 flex items-center justify-center text-[5px]">W</div>
              </div>
            </div>
          </div>
          <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/10 flex items-center gap-1.5">
            <ShieldCheck className="w-3 h-3 text-green-400" />
            <span className="text-[9px] font-mono text-white tracking-widest uppercase">{isEn ? 'REFERENCE' : 'REFERENZ'}</span>
          </div>
        </div>
      )
    },
    {
      id: 'h-therm-window',
      type: 'image',
      title: 'H-THERM Echtglas-Dekor',
      caption: '🏢 Diskreter Sichtschutz & stilvoller Markenauftritt für H-THERM GmbH. Echtglas-Dekorfolierung in edler Sandstrahloptik, präzise geplottet und blasenfrei nassverklebt. Ein wahrer Blickfang für Büros! #folierung #frostedglass #htherm #werbetechnik #sichtschutz',
      likes: 98,
      comments: 9,
      location: 'Zentralschweiz',
      date: 'Vor 1 Woche',
      renderVisual: () => (
        <div className="absolute inset-0 bg-neutral-900 flex flex-col justify-between overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-neutral-800 to-gray-700" />
          {/* Glass Decor Illustration */}
          <div className="absolute inset-6 bg-white/10 backdrop-blur-md rounded-lg border border-white/20 shadow-inner flex flex-col justify-between p-4">
            <div className="w-full h-px bg-white/20" />
            <div className="text-center py-2">
              <span className="text-[14px] font-mono tracking-widest font-bold text-white uppercase block">H-THERM</span>
              <span className="text-[6px] text-white/60 tracking-wider uppercase block mt-0.5">HEIZUNG & SANITÄR</span>
            </div>
            <div className="w-full h-px bg-white/20" />
          </div>
          <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/10 flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-green-400" />
            <span className="text-[9px] font-mono text-white tracking-widest uppercase">{isEn ? 'Frosted Glass' : 'Echtglas-Stil'}</span>
          </div>
        </div>
      )
    },
    {
      id: 'plotter-precision',
      type: 'image',
      title: 'YLRK plotter precision',
      caption: '📐 Qualität entsteht im Detail! Hier schneidet unser Hochleistungsplotter hauchdünne, extrem witterungsbeständige Folien für die nächste Fahrzeugbeschriftung. Millimeterarbeit für perfekte Konturen! #precision #werbetechnik #schneideplotter #ylrk #reinach',
      likes: 121,
      comments: 11,
      location: 'YLRK Atelier, Reinach BL',
      date: 'Vor 2 Wochen',
      renderVisual: () => (
        <div className="absolute inset-0 bg-neutral-900 flex flex-col justify-between overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-[#151515] to-[#252525]" />
          {/* Stylized Plotter representation */}
          <div className="absolute inset-0 flex flex-col justify-center items-center">
            <div className="relative w-40 h-2 bg-neutral-800 border border-neutral-700 rounded-full" />
            <div className="w-32 h-20 bg-brand-cyan/20 border border-brand-cyan/40 relative overflow-hidden flex items-center justify-center">
              <div className="absolute top-0 bottom-0 left-[45%] w-px bg-brand-cyan" />
              {/* Plotter needle pen and sparkles */}
              <div className="absolute top-1/2 left-[45%] transform -translate-x-1/2 -translate-y-1/2 flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-brand-cyan animate-spin" style={{ animationDuration: '6s' }} />
              </div>
              <span className="font-mono text-[8px] text-brand-cyan/80 tracking-wider">PRECISE_CUT_YLRK</span>
            </div>
            <div className="relative w-40 h-1 bg-neutral-800 border border-neutral-700 rounded-full mt-1" />
          </div>
          <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/10 flex items-center gap-1.5">
            <span className="text-[9px] font-mono text-brand-cyan tracking-widest uppercase">PREZISION_TECH</span>
          </div>
        </div>
      )
    }
  ];

  const feedPosts = feedPostsRaw.map(post => {
    if (post.id === 'tesla-wrap') {
      return {
        ...post,
        caption: isEn 
          ? '🔥 TESLA MODEL Y FULL WRAP! Sporty partial wrapping with matte white ip3 decals, precision contour cuts on satin black for ip3 architektur. Perfectly executed under our modern honeycomb LEDs. #carwrap #tesla #ylrk #wrapping #reinach'
          : post.caption,
        location: isEn ? 'YLRK Atelier, Reinach, Switzerland' : post.location,
        date: isEn ? '2 days ago' : post.date,
      };
    }
    if (post.id === 'hagex-fleet') {
      return {
        ...post,
        caption: isEn
          ? '🚀 And the next fleet vehicle for HAGEX HAUSHALTSGERÄTE is ready for swiss roads! Radiant white branding on deep black with long-lasting premium wrap. #hagex #ylrk #branding #fleetbranding'
          : post.caption,
        location: isEn ? 'Canton Baselland, Switzerland' : post.location,
        date: isEn ? '4 days ago' : post.date,
      };
    }
    if (post.id === 'h-therm-window') {
      return {
        ...post,
        caption: isEn
          ? '🏢 Discreet privacy shield & stylish branding for H-THERM GmbH. Real sandblasted frosted glass decoration film, precisely plotted and applied. #frostedglass #htherm #privacy'
          : post.caption,
        location: isEn ? 'Central Switzerland' : post.location,
        date: isEn ? '1 week ago' : post.date,
      };
    }
    if (post.id === 'plotter-precision') {
      return {
        ...post,
        caption: isEn
          ? '📐 Quality is in the details! Here our heavy-duty high quality plotter cuts razor-thin, extremely weather-proof wrapping foils. #precision #ylrk #reinach'
          : post.caption,
        location: isEn ? 'YLRK Atelier, Reinach, Switzerland' : post.location,
        date: isEn ? '2 weeks ago' : post.date,
      };
    }
    return post;
  });

  return (
    <section id="daily-insights" className="py-24 bg-brand-surface relative z-10 border-t border-black/5 overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-brand-cyan/5 rounded-full blur-[80px] pointer-events-none translate-x-1/2 -translate-y-1/2" />
      <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-black/5 rounded-full blur-[60px] pointer-events-none -translate-x-1/2 translate-y-1/2" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="flex flex-col xl:flex-row items-center gap-12 max-w-6xl mx-auto">
          
          {/* Feed Content Block */}
          <div className="flex-1 text-center xl:text-left">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-brand-bg mb-6 shadow-sm border border-black/5 text-brand-cyan"
            >
              <InstagramIcon size={32} />
            </motion.div>
            
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-3xl md:text-4xl font-display font-bold mb-4"
            >
              {isEn ? (
                <>Daily Insights & <span className="text-brand-cyan">New Projects</span></>
              ) : (
                <>Tägliche Einblicke & <span className="text-brand-cyan">neue Projekte</span></>
              )}
            </motion.h2>
            
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="text-brand-muted text-lg mb-8 leading-relaxed max-w-xl mx-auto xl:mx-0"
            >
              {isEn ? (
                <>Experience real Swiss craftsmanship first-hand! On our Instagram channel <span className="font-semibold text-brand-text">@beschriftungen.ylrk</span> we share fresh before-and-after pictures, live-wrapping videos like our Tesla transformation, and behind-the-scenes insights from our workshop in Reinach.</>
              ) : (
                <>Erleben Sie echte Schweizer Handwerkskunst hautnah! Auf unserem Instagram-Kanal <span className="font-semibold text-brand-text">@beschriftungen.ylrk</span> teilen wir frische Vorher-Nachher-Bilder, Live-Wrapping Videos wie unseren Tesla-Umbau und Einblicke in unsere Werkstatt in Reinach.</>
              )}
            </motion.p>
            
            <motion.a 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 }}
              href="https://www.instagram.com/beschriftungen.ylrk"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 bg-brand-cyan hover:bg-brand-cyan/90 text-white px-8 py-4 rounded font-bold uppercase transition-all shadow-md hover:shadow-lg transform hover:-translate-y-0.5"
            >
              <InstagramIcon size={20} />
              {isEn ? 'Follow @beschriftungen.ylrk' : '@beschriftungen.ylrk folgen'}
            </motion.a>
          </div>

          {/* Interactive Instagram Feed Mock Grid */}
          <div className="w-full max-w-lg xl:max-w-xl grid grid-cols-2 gap-4">
            {/* Hidden file input for file uploading */}
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleFileChange} 
              accept="image/*,video/*" 
              className="hidden" 
            />

            {feedPosts.map((post) => {
              const hasCustom = !!customMedias[post.id];
              
              return (
                <div 
                  key={post.id}
                  onClick={() => setZoomedPost(post)}
                  className="relative aspect-square rounded-2xl overflow-hidden border border-black/5 hover:border-black/15 shadow-sm hover:translate-y-[-4px] hover:scale-[1.02] hover:shadow-lg cursor-pointer group transition-all duration-300"
                >
                  {/* Post visual asset */}
                  {hasCustom ? (
                    customMedias[post.id].isVideo ? (
                      <video
                        src={customMedias[post.id].url}
                        className="absolute inset-0 w-full h-full object-cover"
                        autoPlay
                        muted
                        loop
                        playsInline
                      />
                    ) : (
                      <img
                        src={customMedias[post.id].url}
                        className="absolute inset-0 w-full h-full object-cover"
                        alt={post.title}
                      />
                    )
                  ) : (
                    post.renderVisual()
                  )}

                  {/* Glassmorphic Indicator Grid Overlay */}
                  <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px] opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-between p-4 text-white z-10">
                    <div className="flex justify-between items-center" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center gap-1.5 bg-black/60 backdrop-blur-sm px-2.5 py-1 rounded-full border border-white/10">
                        <InstagramIcon size={12} className="text-pink-500" />
                        <span className="text-[9px] font-mono tracking-wider font-semibold">@beschriftungen.ylrk</span>
                      </div>
                      
                      {/* Media Upload Buttons */}
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => {
                            setUploadTargetId(post.id);
                            fileInputRef.current?.click();
                          }}
                          className="p-1 px-2 rounded-full bg-brand-cyan hover:bg-brand-cyan/85 text-white text-[9px] uppercase font-bold flex items-center gap-1 transition-all transform hover:scale-105 active:scale-95 border border-white/10"
                          title={isEn ? "Upload own photo or video" : "Eigenes Foto oder Video hochladen"}
                        >
                          <Camera className="w-3 h-3" />
                          <span>{t('promo.customUpload') || 'Upload'}</span>
                        </button>
                        
                        {hasCustom && (
                          <button
                            onClick={async () => {
                              if (confirm(isEn ? 'Really delete this custom image/video?' : 'Dieses Custom-Bild/Video wirklich löschen?')) {
                                const success = await deleteStoredInstagramImage(post.id);
                                if (success) {
                                  URL.revokeObjectURL(customMedias[post.id].url);
                                  const updated = { ...customMedias };
                                  delete updated[post.id];
                                  setCustomMedias(updated);
                                }
                              }
                            }}
                            className="p-1 rounded-full bg-red-500 hover:bg-red-600 text-white transition-all transform hover:scale-105"
                            title={isEn ? "Reset" : "Zurücksetzen"}
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Center action indicator: Zoom */}
                    <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center gap-2">
                      <div className="w-12 h-12 rounded-full bg-white/25 backdrop-blur-md flex items-center justify-center border border-white/20 scale-90 group-hover:scale-100 transition-transform duration-300">
                        <ZoomIn className="w-6 h-6 text-white" />
                      </div>
                      <span className="text-[11px] font-bold font-sans uppercase tracking-[0.2em] text-white/90 drop-shadow-sm">
                        {isEn ? 'Enlarge' : 'Vergrössern'}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

        </div>
      </div>

      {/* Lightbox modal zoom */}
      <AnimatePresence>
        {zoomedPost && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setZoomedPost(null)}
            className="fixed inset-0 bg-black/95 backdrop-blur-md z-[100] flex items-center justify-center p-4 sm:p-6"
          >
            {/* Close button */}
            <button
              onClick={() => setZoomedPost(null)}
              className="absolute top-6 right-6 text-white/70 hover:text-white bg-white/10 hover:bg-white/20 p-3 rounded-full transition-all duration-200 z-[110]"
              aria-label={isEn ? "Close" : "Schliessen"}
            >
              <X className="w-6 h-6" />
            </button>

            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              transition={{ type: "spring", damping: 25, stiffness: 350 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-brand-surface border border-black/10 rounded-2xl max-w-2xl w-full overflow-hidden shadow-2xl flex flex-col z-[105]"
            >
              <div className="relative w-full aspect-square bg-neutral-950 overflow-hidden">
                {customMedias[zoomedPost.id] ? (
                  customMedias[zoomedPost.id].isVideo ? (
                    <video
                      src={customMedias[zoomedPost.id].url}
                      className="absolute inset-0 w-full h-full object-contain"
                      autoPlay
                      controls
                      loop
                      playsInline
                    />
                  ) : (
                    <img
                      src={customMedias[zoomedPost.id].url}
                      className="absolute inset-0 w-full h-full object-contain"
                      alt={zoomedPost.title}
                    />
                  )
                ) : (
                  zoomedPost.id === 'tesla-wrap' && localVideoUrl ? (
                    <video 
                      src={localVideoUrl} 
                      autoPlay 
                      controls
                      loop 
                      playsInline 
                      className="absolute inset-0 w-full h-full object-contain"
                    />
                  ) : (
                    zoomedPost.renderVisual()
                  )
                )}
              </div>
              
              <div className="flex justify-between items-center px-6 py-4 bg-brand-surface border-t border-black/5">
                <a 
                  href="https://www.instagram.com/beschriftungen.ylrk" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-xs font-bold text-brand-cyan hover:underline uppercase transition-all"
                >
                  {isEn ? 'View on Instagram' : 'Auf Instagram ansehen'}
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
                <button
                  onClick={() => setZoomedPost(null)}
                  className="text-xs font-bold text-brand-muted hover:text-brand-text uppercase transition-all"
                >
                  {isEn ? 'Close' : 'Schliessen'}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}

