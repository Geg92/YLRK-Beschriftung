import React, { useState, useRef, useEffect } from 'react';
import { Upload } from 'lucide-react';

export function Logo({ className = "" }: { className?: string }) {
  const [imgSrc, setImgSrc] = useState<string | null>(null);
  const [imgError, setImgError] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const savedLogo = localStorage.getItem('custom_logo');
    if (savedLogo) {
      setImgSrc(savedLogo);
    } else {
      setImgSrc("/1000082428.png");
    }
  }, []);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target?.result as string;
        setImgSrc(base64);
        localStorage.setItem('custom_logo', base64);
        setImgError(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerUpload = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    fileInputRef.current?.click();
  };

  return (
    <div className={`flex items-center relative group ${className}`}>
      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleFileUpload} 
        accept="image/*" 
        className="hidden" 
      />
      
      {imgSrc && !imgError ? (
        <a href="#home" title="YLRK Beschriftungen Startseite" className="relative inline-block">
          <img
            src={imgSrc}
            alt="YLRK Beschriftungen Logo"
            className="h-[44px] sm:h-[56px] w-auto object-contain select-none transition-transform duration-300 hover:scale-[1.02] drop-shadow-sm mix-blend-multiply"
            style={{
              maxHeight: '64px',
            }}
            onError={() => setImgError(true)}
          />
          <button 
            onClick={triggerUpload}
            className="absolute -bottom-1 -right-3 bg-brand-surface text-brand-text p-1.5 rounded-full opacity-0 group-hover:opacity-100 hover:bg-black hover:text-white transition-all duration-200 shadow-md border border-black/10 z-10"
            title="Eigenes Logo hochladen"
          >
            <Upload size={14} />
          </button>
        </a>
      ) : (
        <button 
          onClick={triggerUpload}
          className="flex flex-col items-center justify-center h-[44px] sm:h-[56px] px-6 border border-dashed border-black/30 bg-black/5 rounded-lg text-brand-text text-[10px] sm:text-xs text-center transition-transform duration-300 hover:scale-[1.02] cursor-pointer hover:bg-black/10"
        >
          <span className="font-bold flex items-center gap-1.5 mb-0.5">
            <Upload size={14} />
            Logo hochladen
          </span>
          <span className="text-black/60">Klicken um PNG/SVG zu wählen</span>
        </button>
      )}
    </div>
  );
}




